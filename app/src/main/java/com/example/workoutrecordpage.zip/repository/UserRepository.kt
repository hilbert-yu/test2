package com.example.workoutrecordpage.repository

import android.app.Application
import com.example.workoutrecordpage.dao.UserDao
import com.example.workoutrecordpage.database.UserRoomDatabase
import com.example.workoutrecordpage.model.User
import kotlinx.coroutines.flow.Flow

class UserRepository (application: Application) {

    private var userDao: UserDao =
        UserRoomDatabase.getDatabase(application).userDao()

    val allUsers: Flow<List<User>> = userDao.getAllUsers()


    suspend fun insert(user: User) {
        userDao.insertUser(user)
    }

    suspend fun delete(user: User) {
        userDao.deleteUser(user)
    }

    suspend fun update(user: User) {
        userDao.updateUser(user)
    }
}